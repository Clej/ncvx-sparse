import numpy as np
from .scad_coordinate_descent import SCADnet, MultiTaskSCADnet